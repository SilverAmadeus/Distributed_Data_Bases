insert into tipo_almacenamiento (tipo_almacenamiento_id, clave, descripcion) values (1, 'SSD', 'Almacenamiento de estado solido');
insert into tipo_almacenamiento (tipo_almacenamiento_id, clave, descripcion) values (2, 'HHD', 'Almacenamiento convencional');
